<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Home Page</title>
      <meta content="" name="descriptison">
      <meta content="" name="keywords">
      <meta name="csrf-token" content="{{ csrf_token() }}" />
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Dosis:300,400,500,,600,700,700i|Lato:300,300i,400,400i,700,700i" rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
      <link href="{{ url('frontassets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/vendor/icofont/icofont.min.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/vendor/boxicons/css/boxicons.min.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/vendor/venobox/venobox.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/vendor/line-awesome/css/line-awesome.min.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/vendor/owl.carousel/assets/owl.carousel.min.css') }}" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <link href="{{ url('frontassets/css/style.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/css/style2.css') }}" rel="stylesheet">
   </head>
   <style type="text/css">
      .personal_input
      {
      height: 40px;border:0;border-bottom: 2px solid #5F5F5F;border-radius: 0;margin-top: -15px;outline: none;width: 100%;  
      }
      .personal_label
      {
      font-size: 16px;font-weight: 500;color: black; 
      }
      .personal_div2
      {
      padding-left: 29px;padding-right: 29px; margin-top: 20px;
      }
      label {
    display: inline-block;
    margin-bottom: 1.5rem;
}
   </style>
   <body>
       @include("web.header")
       @include("web.category_slider")

      <div class="container-fluid" style="margin-top: 25px;width: 91.5%;">
         <div class="row">
            <div class="col-xl-12">
               <div class="card shadow">
                  <h3 style="margin: 13px 0px 15px 15px;font-size: 20px;">Add ADDRESS DETAILS </h3>
               </div>
            </div>
         </div>
      </div>
      <div class="container-fluid" style="margin-top: 35px;width: 95%;">
         <form method="POST" action="#">
            {{ csrf_field() }}
            <div class="row">
            <div class="col-xl-12">
            <div class="form-group personal_div2">

                      <label for="usr" class="personal_label">Select Address Type<i class="fab fa-diaspora" style="color: red;font-size: 11px;"></i></label>
                      <select class="form-control" name="type" id="type" >
                          <option >Select Address Type</option>
                          <option value="Home" >Home</option>
                          <option value="Office" >Office</option>
                          <option value="Other" >Other</option>
                      </select>
                      </div>
                        </div>
            <div class="col-xl-6">
               <div class="form-group personal_div2">
                  <label for="usr" class="personal_label">Select City <i class="fab fa-diaspora" style="color: red;font-size: 11px;"></i></label>
                  <select class="form-control" name="city_id" id="city_id" >
                  <option value="">Salect City </option>
                  @foreach($city as $city)
                  <option value="{{$city->city_id}}"><span style="font-weight:bold">{{$city->city_name}}</span></option>
                  @endforeach  
                  </select>
               </div>
            </div>
            <div class="col-xl-6">
               <div class="form-group personal_div2">
                  <label for="usr" class="personal_label">Select near by <i class="fab fa-diaspora" style="color: red;font-size: 11px;"></i></label>
                  <select class="form-control unshow" name="area_id" id="area_id" >
                  </select>
               </div>
            </div>
            <div class="col-xl-6">
               <div class="form-group personal_div2">
                  <label for="usr" class="personal_label">House No <i class="fab fa-diaspora" style="color: red;font-size: 11px;"></i></label>
                  <input type="text"  id="houseno" class="personal_input" name="houseno"  value="">
               </div>
            </div>
             <div class="col-xl-6">
               <div class="form-group personal_div2">
               <label for="usr" class="personal_label">Pincode <i class="fab fa-diaspora" style="color: red;font-size: 11px;"></i></label>
               <input type="text"  id="pincode" class="personal_input"  name="pincode"  value="">
               </div>
            </div>
            <div class="col-xl-6">
               <div class="form-group personal_div2">
               <label for="usr" class="personal_label">State <i class="fab fa-diaspora" style="color: red;font-size: 11px;"></i></label>
               <input type="text"  id="state" class="personal_input" name="state"  value="">
               </div>
            </div>
            <div class="col-xl-6">
               <div class="form-group personal_div2">
                  <label for="usr" class="personal_label">Address Line 1<i class="fab fa-diaspora" style="color: red;font-size: 11px;"></i></label>
                  <input type="text"  id="address" class="personal_input"  name="address"  value="">
               </div>
            </div>
    
            
            
            <div class="col-xl-12">
               <center>
                  <button type="button" class="edit_button23" id="addressinsert">Submit</button>

               </center>
            </div>
            </div>
         </form>
      </div>
      <main id="main" class="shadow" style="margin-top: 40px;">
         <!-- ======= About Section ======= -->
         <section id="about" class="about">
            <div class="container" style="margin-top: -50px;margin-bottom: -30px;">
               <div class="row">
                  <div class="col-xl-4 col-lg-4 d-flex justify-content-center align-items-stretch">
                     <div class="icon-box">
                        <div class="icon"><i class="fas fa-hand-holding-usd"></i></div>
                        <h4 class="title"><a href="">Best Price & Offers</a></h4>
                        <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
                     </div>
                  </div>
                  <div class="col-xl-4 col-lg-4 d-flex justify-content-center align-items-stretch">
                     <div class="icon-box">
                        <div class="icon"><i class="fas fa-inbox"></i></div>
                        <h4 class="title"><a href="">Wide Assorment</a></h4>
                        <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
                     </div>
                  </div>
                  <div class="col-xl-4 col-lg-4 d-flex justify-content-center align-items-stretch">
                     <div class="icon-box">
                        <div class="icon"><i class="fas fa-rupee-sign"></i></div>
                        <h4 class="title"><a href="">Easy Return</a></h4>
                        <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- End About Section -->
      </main>
      <!-- End #main -->
       @include("web.footer")
      <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
      <!-- Vendor JS Files -->
      <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
      <!-- Vendor JS Files -->
      <script src="{{ url('frontassets/vendor/jquery/jquery.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/jquery.easing/jquery.easing.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/php-email-form/validate.js') }}"></script>
      <script src="{{ url('frontassets/vendor/venobox/venobox.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/waypoints/jquery.waypoints.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/counterup/counterup.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/isotope-layout/isotope.pkgd.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/owl.carousel/owl.carousel.min.js') }}"></script>
      <!-- Template Main JS File -->
      <script src="{{ url('frontassets/js/main.js') }}"></script>
   </body>
</html>
<script>
   $(document).ready(function(){
     $('#owl-one').owlCarousel({
       loop:true,
       margin:10,
       nav:true,
                       
   responsive: {
           0:{
               items:1
           },
           600:{
               items:4
           },
           1000:{
               items:7
           }
       }
   })
        $( ".owl-prev").html('<img src="{{ url("frontassets/img/l1.png")}}" height="45" style="margin-left:10px;margin-top:30px;" height="55"  class="imgkl2 shadow">');
      $( ".owl-next").html('<img src="{{ url("frontassets/img/r2.png")}}" height="45" style="margin-right:10px;margin-top:30px;" height="55" class="imgkl2 shadow">');
   });
   
   
</script>
<script type="text/javascript">
      $(document).ready(function(){

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
    $("#addressinsert").click(function(e){
      e.preventDefault();
      debugger;
        var type = $('#type').val();
        var city_id = $('#city_id').val();
        var area_id = $('#area_id').val();
        var houseno = $('#houseno').val();
        var pincode = $('#pincode').val();
        var state = $('#state').val();
        var address = $('#address').val();
        
         $.ajax({
           type:'post',
           url:"{{route('addaddressdetailsdata')}}",
           data:{type:type,city_id:city_id,area_id:area_id,houseno:houseno,pincode:pincode,state:state,address:address},
           success: function(result){
            if(result == 1)
                  {
              alert("Address added Successfully");
             window.location.href="{{route('webprofile')}}";
            }else
                  {
                     alert("Address not save");

            }
           }
         });
      });

    $('select[name="city_id"]').on('change', function() {
        
        var city_id = $(this).val();
                $.ajax({
                    url: "getbyarealist/"+encodeURI(city_id),
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                      debugger;
                      if ($.trim(data)){ 
                        var html = "";
                        for(var i=0;i<data.length;i++){ 
                            html+="<option value="+data[i].area_id+">"+data[i].area_name+"</option>";
                        }
                        $("#area_id").html(html);
                        $('.unshow').show();
                      }else{   
                            alert("Area not Exist");
                             $('.unshow').hide();
    
                            }
                        
                    }
                });
           
    });
   });
    </script>
<style type="text/css">
   .imgkl2{
   background-color: white;
   }
   .imgkl2:hover
   {
   background: white !important;
   }
</style>