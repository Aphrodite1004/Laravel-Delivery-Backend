<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Home Page</title>
      <meta content="" name="descriptison">
      <meta content="" name="keywords">
      <meta name="csrf-token" content="{{ csrf_token() }}" />
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Dosis:300,400,500,,600,700,700i|Lato:300,300i,400,400i,700,700i" rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
      <link href="{{ url('frontassets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/vendor/icofont/icofont.min.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/vendor/boxicons/css/boxicons.min.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/vendor/venobox/venobox.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/vendor/line-awesome/css/line-awesome.min.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/vendor/owl.carousel/assets/owl.carousel.min.css') }}" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <link href="{{ url('frontassets/css/style.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/css/style2.css') }}" rel="stylesheet">
      <link href="{{ url('frontassets/css/style3.css') }}" rel="stylesheet">

   </head>
   <body>
       @include("web.groceryheader")
       @include("web.category_slider")
      <style type="text/css">
       
         @media only screen and (max-width: 768px) {
         .checkout_cardbody
         {
         width: 100%;margin-left: 0px !important;
         }
         .checkout_input
         {
         max-width:95%;
         }
         .checkout_next
         {
         width: 100%;
         margin-top: 15px;margin-left: 0px;
         }
         .checkout_order
         {
         width: 100%;
         }
         #nono
         {
         min-height: 320px;
         }
         #nono2
         {
         min-height: 80px;
         }
         }
      </style>
      <div class="container-fluid checkout_cont">
         <div class="row">
            <div class="col-xl-3">
                  <div class="card shadow">
                     <h3 style="margin: 15px 0px 35px 18px;font-size: 20px;"><b>My Account</b></h3>
                     <style type="text/css">
                        .myaccount_side
                        {
                        height: 60px;padding-top: 15px;cursor: pointer;
                        }
                        .myaccount_side_p
                        {
                        font-size: 17.5px;margin-left: 20px;font-weight: 500; 
                        }
                     </style>
                     <div id="side1" class="myaccount_side" style="background-color: #4BA345;">
                        <p class="myaccount_side_p" id="para1" style="color: white;"><i class="fas fa-box"></i> &nbsp;My Orders <span style="float: right;"><i class="fas fa-angle-double-right" style="margin-right: 20px;"></i></span></p>
                     </div>
                     <div id="side2" style="background-color: white;" class="myaccount_side">
                        <p class="myaccount_side_p" id="para2" style="color: black;"><i class="fas fa-box"></i> &nbsp;Active Orders <span style="float: right;"><i class="fas fa-angle-double-right" style="margin-right: 20px;"></i></span></p>
                     </div>
                     <div id="side7" style="background-color: white;" class="myaccount_side">
                        <p class="myaccount_side_p" id="para7" style="color: black;"><i class="fa fa-gift"></i> &nbsp;Rewards<span style="float: right;"><i class="fas fa-angle-double-right" style="margin-right: 20px;"></i></span></p>
                     </div>
                     <div id="side8" style="background-color: white;" class="myaccount_side">
                        <p class="myaccount_side_p" id="para8" style="color: black;"><i class="fa fa-wallet"></i> &nbsp;Wallet<span style="float: right;"><i class="fas fa-angle-double-right" style="margin-right: 20px;"></i></span></p>
                     </div>
                     <div id="side3" style="background-color: white;" class="myaccount_side">
                        <p class="myaccount_side_p" id="para3" style="color: black;"><i class="far fa-user-circle"></i> &nbsp;Personal Details <span style="float: right;"><i class="fas fa-angle-double-right" style="margin-right: 20px;"></i></span></p>
                     </div>
                     <div id="side4" style="background-color: white;" class="myaccount_side">
                        <p class="myaccount_side_p" id="para4" style="color: black;"><i class="far fa-address-card"></i> &nbsp;Delivery Address <span style="float: right;"><i class="fas fa-angle-double-right" style="margin-right: 20px;"></i></span></p>
                     </div>
                     <div id="side5" style="background-color: white;" class="myaccount_side">
                        <p class="myaccount_side_p" id="para5" style="color: black;"><i class="fas fa-people-carry"></i> &nbsp;Customer Service <span style="float: right;"><i class="fas fa-angle-double-right" style="margin-right: 20px;"></i></span></p>
                     </div>
                     <br><br>
                  </div>
            </div>
            <div class="col-xl-9 rightacc">

                  @if (Session::has('message'))
                   <div class="alert alert-success">
                       <ul>
                          {!! Session::get('message') !!}
                       </ul>
                   </div>
               @endif
                  <div id="div1" class="card shadow" >
                     <h3 style="margin: 13px 0px 30px 22px;font-size: 22px;"> <i class="fas fa-box" style="color: #4BA345;"></i>&nbsp;My Orders</h3>
                     <center class="saved_mob">
                        <table class="table saved_mob2" style="width: 95%;border: 5px solid #DEE2E6;margin-bottom: 30px;">
                           <thead>
                              <tr >
                                 <th scope="col" style="width: 30%;">Order Placed On:</th>
                                 <th scope="col" style="width: 20%;">Order Amount:</th>
                                <!--  <th scope="col" style="width: 10%;">Items:</th> -->
                                 <th scope="col" style="width: 20%;">Status:</th>
                                 <th scope="col" style="width: 22%;">Action:</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php foreach($orders as $orders) {?>
                              <tr style="line-height: 40px;">
                                 <th scope="row"> {{date('d F Y',strtotime($orders->order_date))}}</th>
                                 <td>Rs.{{ $orders->total_price}}</td>
                                 <!-- <td>2</td> -->
                                 <td style="color: orange">{{ $orders->order_status}}</td>
                                 <td style="color: #4BA345;cursor: pointer;" ><i class="fas fa-map-marker-alt" ></i> <span style="font-weight: 500" onclick="getorderdetails({{$orders->order_id}})">View Order</span></td>
                              </tr>
                              <?php }?>
                           </tbody>
                        </table>
                     </center>
                  </div>
                  <div class="modal fade" id="orderdetails" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
                     <div class="modal-dialog modalacc_doc" role="document">
                        <div class="modal-content modalacc_content">
                           <div class="modal-header">
                              <h5 class="modal-title modal_head" id="exampleModalLabel"><i class="fas fa-map-marker-alt" style="color: #F27A35;"></i> View Order</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                              </button>
                           </div>
                           <div class="modal-body" style="padding: 30px 20px 20px 40px">
                              <div class="">
                                 <div class="row">
                                    <div class="col-lg-4 col-md-6">
                                       <p style="font-weight: 500;font-size: 15.5px;"> <i class="fas fa-angle-double-right" style="color: #f27a35;"></i> Delivery Address:</p>
                                       <p class="myaccount_para3" id="username">Kuwar Raman Singh</p>
                                       <p class="myaccount_para2" id="usernumber">9876543210</p>
                                       <p class="myaccount_para" id="useraddress">Your Local Address</p>
                           
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                       <p style="font-weight: 500;font-size: 15.5px;"><i class="fas fa-angle-double-right" style="color: #f27a35;"></i>  Payment Info :</p>
                                       <p class="myaccount_para4">Status : <span style="color: #f27a35;" id="orderstatus">Ready for Dispatch</span></p>
                                       <p class="myaccount_para">Mode : <span id="paymentmethod">COD</span></p>
                                       <p style="font-weight: 500;font-size: 15.5px;"><i class="fas fa-angle-double-right" style="color: #f27a35;"></i> Store Name :</p>
                                       <p class="myaccount_para4" id="storename">R.K trading Company</p>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <p style="font-weight: 500;font-size: 15.5px;"><i class="fas fa-angle-double-right" style="color: #f27a35;"></i> Order Summary :</p>
                                       <p class="myaccount_para4" >Sub-Total : <span style="float: right;" id="subtotal">Rs.1,693</span></p>
                                       <p class="myaccount_para4">Delivery Fee <span style="float: right;" id="deliveryfee">Rs.16</span></p>
                                       <hr style="border-bottom: 8px solid #F6F6F6">
                                       <p class="myaccount_total">Total <span style="float: right;" id="total">Rs.1,712</span></p>
                                       <hr style="border-bottom: 8px solid #F6F6F6">
                                    </div>
                                    <div class="col-xl-12">
                                       <button class="myaccount_cancel" id="orderid" onclick="cancelorder()">Cancel</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="modal fade" id="cancelorderdata" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
                     <div class="modal-dialog modalacc_doc" role="document">
                        <div class="modal-content modalacc_content">
                           <div class="modal-header">
                              <h5 class="modal-title modal_head" id="exampleModalLabel"><i class="fas fa-map-marker-alt" style="color: #F27A35;"></i> Cancel Order</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                              </button>
                           </div>
                           <div class="modal-body" style="padding: 30px 20px 20px 40px">
                               <form method="POST" action="">
                              <div class="">
                                  
                                 <div class="row">
                                    <div class="col-lg-4 col-md-6">
                                       <select class="form-control" name="cancelreason" id="cancelreason">
                                           <?php foreach($ordercancel as $ordercanceldata){ ?>
                                           <option value="{{$ordercanceldata->reason}}">{{$ordercanceldata->reason}}</option>
                                           <?php }?>
                                           </select>
                                    </div>
                                   <button type="button" class="btn btn-primary" id="orderid" onclick="getcancelorder()">Submit</button>
                                 </div>
                              </div>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div id="div2" class="card shadow" style="display: none;">
                     <h3 style="margin: 13px 0px 30px 22px;font-size: 22px;"> <i class="fas fa-box" style="color: #4BA345;"></i>&nbsp;Active Orders</h3>
                     <center class="saved_mob">
                        <table class="table saved_mob2" style="width: 95%;border: 5px solid #DEE2E6;margin-bottom: 30px;">
                           <thead>
                              <tr >
                                 <th scope="col" style="width: 30%;">Order Placed On:</th>
                                 <th scope="col" style="width: 20%;">Order Amount:</th>
                               
                                 <th scope="col" style="width: 20%;">Status:</th>
                                 <th scope="col" style="width: 22%;">Action:</th>
                              </tr>
                           </thead>
                           <tbody>
                            <?php foreach($activeorder as $ordersdata) {?>
                              <tr style="line-height: 40px;">
                                 <th scope="row"> {{date('d F Y',strtotime($ordersdata->order_date))}}</th>
                                 <td>Rs.{{ $ordersdata->total_price}}</td>
                                 <!-- <td>2</td> -->
                                 <td style="color: orange">{{ $ordersdata->order_status}}</td>
                                 <td style="color: #4BA345;cursor: pointer;" ><i class="fas fa-map-marker-alt" ></i> <span style="font-weight: 500" onclick="getorderdetails({{$ordersdata->order_id}})">View Order</span></td>
                              </tr>
                              <?php }?>
                           </tbody>
                        </table>
                     </center>
                  </div>
                 
                  <div id="div7" class="card shadow" style="display: none;">
                     <h3 style="margin: 13px 0px 30px 22px;font-size: 22px;"> <i class="fas fa-box" style="color: #4BA345;"></i>&nbsp;Reward</h3>
                     <!-- <center class="saved_mob"> -->
                       <span style="padding-left:20px;"><b>Total Reward Points: {{ $reward}}</b></span><br><br>
                       <?php if($reward > 0){?>
                       <div class="col-md-3"><button class="btn btn-success" onclick="reedempoint({{ $reward}})">Redeem</button></button></div>
                       <?php }else{?>
                       <div class="col-md-3"><button class="btn btn-success" >Redeem</button></button></div>
                       <?php }?>
                     <!-- </center> -->
                  </div>
                  <div id="div8" class="card shadow" style="display: none;">
                     <h3 style="margin: 13px 0px 30px 22px;font-size: 22px;"> <i class="fas fa-box" style="color: #4BA345;"></i>&nbsp;Wallet</h3>
                        <div id="paymentsuccess"></div>
                          <span style="padding-left:20px;"><span id="wallettotamount"><b>Total Wallet Amount: Rs. {{ $wallet}}</b></span></span><br><br>
                        <div class="col-md-3"><button class="btn btn-success" onclick="openrechargediv()">Recharge wallet</button></button></div>
                        <br><br>
                        <div id="rechargediv" style="display:none;">
                            <label>Amount</label>
                            
                            <input type="text" class="form-control" id="amountrecharge">
                             <br><br>
                            <button class="btn btn-primary" onclick="getpayment()">Payment</button>
                            <br><br>
                        </div>
                  </div>
                  <div id="div3" class="card shadow" style="display: none;">
                     <form method="POST" action="{{ route('webupdateprofile') }}">
                        {{ csrf_field() }}
                     <h3 style="margin: 13px 0px 30px 22px;font-size: 22px;"> <i class="far fa-user-circle" style="color: #4BA345;"></i>&nbsp;Personal Details</h3>
                     <div class="form-group personal_div">
                        <label for="usr" class="personal_label">Name <i class="fab fa-diaspora" style="color: red;font-size: 11px;"></i></label>
                        <input type="text"  id="usr" name="username" class="personal_input" value="{{$profile->user_name}}">
                     </div>
                    
                     <div class="form-group personal_div">
                        <label for="usr" class="personal_label">Email Address <i class="fab fa-diaspora" style="color: red;font-size: 11px;"></i></label>
                        <input type="text"  id="usr" name="useremail" class="personal_input" value="{{$profile->user_email}}">
                     </div>
                     <div class="form-group personal_div">
                        <label for="usr" class="personal_label">Mobile Number <i class="fab fa-diaspora" style="color: red;font-size: 11px;"></i></label>
                        <input type="text"  id="usr" name="mobilenumber" class="personal_input" value="{{$profile->user_phone}}">
                     </div>
                     
                     <center>
                        <button class="myaccout_submit">Submit</button>
                     </center>
                     </form>
                  </div>
       

                  <div id="div4" class="card shadow" style="display: none;padding-bottom: 30px;">
                     <h3 style="margin: 13px 0px 30px 22px;font-size: 22px;"> <i class="far fa-address-card" style="color: #4BA345;"></i>&nbsp;Delivery Address <span class="addnew_acc"><a href="{{ route('addaddressdetails')}}"><i class="fas fa-plus"></i> Add New Address</a></span></h3>
                     <div class="container-fluid" style="margin-left: 8px;width: 98.6%;">
                        <div class="row" >
                           <?php foreach($address as $address){?>
                           <div class="col-xl-6">
                              <div class="card">
                                 <div class="card-header">
                                    <b> {{ $address->user_name}}</b>
                                 </div>
                                 <div class="card-body">
                                    <p style="font-weight: 400;font-size: 15px;color: #666;margin-top: -10px;"> {{ $address->address}}</p>

                                    <p style="font-weight: 400;font-size: 15px;color: #666;margin-top: 1px;">{{ $address->user_number}}</p>
                                    <p class="myaccount_para99">{{ $address->type}}</p>
                                 </div>
                              </div>
                              <p class="myaccount_add"><?php if($address->select_status == 1){?>Default Address<?php } else {?><a onclick="setaddress({{ $address->address_id}})">Set Default Address</a><?php }?> <span style="float: right;"><a href="{{ route('updateaddressdetails', $address->address_id)}}">Edit Address</a></span> </p>
                           </div>
                           <?php }?>
                        </div>
                     </div>
                  </div>

                  <div id="div5" class="card shadow" style="display: none;">
                     <h3 style="margin: 13px 0px 30px 22px;font-size: 22px;"> <i class="fas fa-people-carry" style="color: #4BA345;"></i>&nbsp;Customer Service</h3>
                     <div class="container-fluid" style="width: 98%;">
                        <div class="row">
                           <div class="col-xl-3" style="border-right: 1px solid #D4D4D4;margin-bottom: 20px;">
                              <p style="font-size: 17px;font-weight: 500;margin-top: 60px;"><i class="fas fa-envelope-open-text"></i> Email / Call</p>
                           </div>
                           <div class="col-xl-9">
                              <center>
                                 <p style="font-size: 19px;font-weight: 500;margin-bottom: 30px;"><i class="fas fa-envelope-open-text"></i> Email</p>
                                 <p style="font-size: 18px;font-weight: 500;">In case of any query, Please contact us to below details</p>
                                 <p style="font-size: 19px;font-weight: 500;">Email will be send to:</p>
                                 <p style="font-size: 19px;font-weight: 500;color: #4BA345;margin-top: -16px;">customercare@xyz.com</p>
                                 <p style="font-size: 19px;font-weight: 500;">OR</p>
                                 <p style="font-size: 19px;font-weight: 500;">Call us at:</p>
                                 <p style="font-size: 19px;font-weight: 500;margin-bottom: 30px;color: #4BA345;margin-top: -16px;">18000800000</p>
                              </center>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
         </div>
      </div>
      <input type="hidden" name="userid" id="userid" value="{{ session('userid')}}">
      <br><br>
       @include("web.footer")
      <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
      <!-- Vendor JS Files -->
      <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
      <!-- Vendor JS Files -->
      <script src="{{ url('frontassets/vendor/jquery/jquery.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/jquery.easing/jquery.easing.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/php-email-form/validate.js') }}"></script>
      <script src="{{ url('frontassets/vendor/venobox/venobox.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/waypoints/jquery.waypoints.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/counterup/counterup.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/isotope-layout/isotope.pkgd.min.js') }}"></script>
      <script src="{{ url('frontassets/vendor/owl.carousel/owl.carousel.min.js') }}"></script>
      <!-- Template Main JS File -->
      <script src="{{ url('frontassets/js/main.js') }}"></script>
      <script type="text/javascript">
   $(document).ready(function(){
      $('#owl-one').owlCarousel({
       loop:true,
       margin:10,
       nav:true,
                       
   responsive: {
           0:{
               items:1
           },
           600:{
               items:4
           },
           1000:{
               items:7
           }
       }
   })
      $( ".owl-prev").html('<img src="{{ url('frontassets/img/l1.png') }}" height="45" style="margin-left:10px;margin-top:30px;" height="55"  class="imgkl2 shadow">');
      $( ".owl-next").html('<img src="{{ url('frontassets/img/r2.png') }}" height="45" style="margin-right:10px;margin-top:30px;" height="55" class="imgkl2 shadow">');
      
       $('#side1').click(function(){     
           $('#div1').show();  
           $('#div2').hide();  
           $('#div3').hide();  
           $('#div4').hide();  
           $('#div5').hide(); 
           $('#div7').hide(); 
           $('#div8').hide(); 
           $('#side1').css('background-color','#4BA345');    
           $('#side2').css('background-color','white');    
           $('#side3').css('background-color','white');    
           $('#side4').css('background-color','white');    
           $('#side5').css('background-color','white');
            $('#side7').css('background-color','white');
             $('#side8').css('background-color','white'); 
   
           $('#para1').css('color','white');    
           $('#para2').css('color','black');    
           $('#para3').css('color','black');    
           $('#para4').css('color','black');    
           $('#para5').css('color','black');
            $('#para7').css('color','black');
             $('#para8').css('color','black');    
         
       });
   
        $('#side2').click(function(){     
           $('#div1').hide();  
           $('#div2').show();  
           $('#div3').hide();  
           $('#div4').hide();  
           $('#div5').hide();
            $('#div7').hide(); 
           $('#div8').hide();  
           $('#side2').css('background-color','#4BA345');    
           $('#side1').css('background-color','white');    
           $('#side3').css('background-color','white');    
           $('#side4').css('background-color','white');    
           $('#side5').css('background-color','white'); 
             $('#side7').css('background-color','white');
             $('#side8').css('background-color','white'); 
   
           $('#para2').css('color','white');    
           $('#para1').css('color','black');    
           $('#para3').css('color','black');    
           $('#para4').css('color','black');    
           $('#para5').css('color','black');  
            $('#para7').css('color','black');
             $('#para8').css('color','black');     
         
       });
   
         $('#side3').click(function(){     
           $('#div1').hide();  
           $('#div2').hide();  
           $('#div3').show();  
           $('#div4').hide();  
           $('#div5').hide(); 
            $('#div7').hide(); 
           $('#div8').hide(); 
           $('#side3').css('background-color','#4BA345');    
           $('#side2').css('background-color','white');    
           $('#side1').css('background-color','white');    
           $('#side4').css('background-color','white');    
           $('#side5').css('background-color','white');
             $('#side7').css('background-color','white');
             $('#side8').css('background-color','white'); 
   
               $('#para3').css('color','white');    
           $('#para2').css('color','black');    
           $('#para1').css('color','black');    
           $('#para4').css('color','black');    
           $('#para5').css('color','black');   
            $('#para7').css('color','black');
             $('#para8').css('color','black');    
         
       });
   
          $('#side4').click(function(){     
           $('#div1').hide();  
           $('#div2').hide();  
           $('#div3').hide();  
           $('#div4').show();  
           $('#div5').hide(); 
            $('#div7').hide(); 
           $('#div8').hide(); 
           $('#side4').css('background-color','#4BA345');    
           $('#side2').css('background-color','white');    
           $('#side3').css('background-color','white');    
           $('#side1').css('background-color','white');    
           $('#side5').css('background-color','white'); 
             $('#side7').css('background-color','white');
             $('#side8').css('background-color','white'); 
   
               $('#para4').css('color','white');    
           $('#para2').css('color','black');    
           $('#para3').css('color','black');    
           $('#para1').css('color','black');    
           $('#para5').css('color','black'); 
            $('#para7').css('color','black');
             $('#para8').css('color','black');     
         
       });
   
           $('#side5').click(function(){     
           $('#div1').hide();  
           $('#div2').hide();  
           $('#div3').hide();  
           $('#div4').hide();  
           $('#div5').show(); 
            $('#div7').hide(); 
           $('#div8').hide(); 
           $('#side5').css('background-color','#4BA345');    
           $('#side2').css('background-color','white');    
           $('#side3').css('background-color','white');    
           $('#side4').css('background-color','white');    
           $('#side1').css('background-color','white'); 
             $('#side7').css('background-color','white');
             $('#side8').css('background-color','white');   
   
               $('#para5').css('color','white');    
           $('#para2').css('color','black');    
           $('#para3').css('color','black');    
           $('#para4').css('color','black');    
           $('#para1').css('color','black'); 
            $('#para7').css('color','black');
             $('#para8').css('color','black');   
         
       });
           $('#side7').click(function(){     
           $('#div1').hide();  
           $('#div2').hide();  
           $('#div3').hide();  
           $('#div4').hide(); 
            $('#div8').hide(); 
             $('#div5').hide();  
           $('#div7').show(); 
           $('#side7').css('background-color','#4BA345');    
           $('#side2').css('background-color','white');    
           $('#side3').css('background-color','white');    
           $('#side4').css('background-color','white');    
           $('#side1').css('background-color','white');
           $('#side8').css('background-color','white'); 
           $('#side5').css('background-color','white');   
   
               $('#para7').css('color','white');    
           $('#para2').css('color','black');    
           $('#para3').css('color','black');    
           $('#para4').css('color','black');    
           $('#para1').css('color','black'); 
            $('#para5').css('color','black'); 
             $('#para8').css('color','black'); 
         
       });
           $('#side8').click(function(){     
           $('#div1').hide();  
           $('#div2').hide();  
           $('#div3').hide();  
           $('#div4').hide();
           $('#div5').hide();
           $('#div7').hide();  
           $('#div8').show(); 
           $('#side8').css('background-color','#4BA345');    
           $('#side2').css('background-color','white');    
           $('#side3').css('background-color','white');    
           $('#side4').css('background-color','white');    
           $('#side1').css('background-color','white'); 
           $('#side5').css('background-color','white');  
           $('#side7').css('background-color','white');    
   
               $('#para8').css('color','white');    
           $('#para2').css('color','black');    
           $('#para3').css('color','black');    
           $('#para4').css('color','black');    
           $('#para1').css('color','black');
            $('#para5').css('color','black');
             $('#para7').css('color','black'); 
         
       });
     
   });
function getorderdetails(orderid)
{
      $.ajaxSetup({
                     headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     }
            });
      $.ajax({
         url: "{{ route('orderideatils') }}",
         type:"POST",
         data:{orderid: orderid},
         success: function(result){
            var obj = JSON.parse(result);
            debugger;
           $('#username').html(obj.address.user_name);
           $('#usernumber').html(obj.address.user_number);
           $('#useraddress').html(obj.address.address);
           $('#orderstatus').html(obj.order.order_status);
           $('#paymentmethod').html(obj.order.payment_method);
           $('#paymentmethod').html(obj.order.payment_method);
           $('#orderid').val(obj.order.order_id);
           $('#storename').html(obj.store.vendor_name);
           $('#subtotal').html('Rs.'+obj.order.price_without_delivery);
           $('#deliveryfee').html('Rs.'+obj.order.delivery_charge);
           $('#total').html('Rs.'+obj.totalprice);

           
           
             $('#orderdetails').modal('show');
         }
      });
}

function cancelorder()
{
   debugger;
   var order_id = $('#orderid').val();
     $.ajaxSetup({
                     headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     }
            });
     $.ajax({
         url: "{{ route('cancelorderload') }}",
         type:"POST",
         data:{order_id: order_id},
         success: function(result){
            var obj = JSON.parse(result);
                $('#orderid').val(obj.orderid);
                $('#orderdetails').modal('hide');
                $('#cancelorderdata').modal('show');
           
          
         }
      });
}
function getcancelorder()
{
     $.ajaxSetup({
                     headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     }
            });
            var orderid = $('#orderid').val();
            var cancelreason = $('#cancelreason').val();
        $.ajax({
         url: "{{ route('cancelorder') }}",
         type:"POST",
         data:{orderid:orderid,cancelreason:cancelreason},
         success: function(result){
            if(result == 1)
            {
               alert('Order cancelled successfully') ;
               location.reload();
            }
               
           
          
         }
      });
}
function openrechargediv()
{
    $('#rechargediv').css('display','block');
}
    function getpayment()
    {
        var amountrecharge = $('#amountrecharge').val();
            $.ajaxSetup({
               headers: {
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               }
            });
            var totalAmount = amountrecharge;
          
            var razorpay_key = "rzp_test_K4YMcaRBxHAFvi";
            var userid = $('#userid').val();
            var options = {
              "key": razorpay_key,
              "amount": (totalAmount*100), // 2000 paise = INR 20
             
              "description": "Payment",
              
              "handler": function (response){
               
                    $.ajax({
                        method: 'post',
                        url: "",
                        data: {
                            "_token": "{{ csrf_token() }}",
                            "razorpay_payment_id": response.razorpay_payment_id,
                            "totalAmount":totalAmount,
                            "userid":userid
                        },
                        success: function (result) {
                        var obj = JSON.parse(result);
                        if(obj.code == 200)
                        {  
                        $('#paymentsuccess').html('<div class="alert alert-success">Wallet Recharge Successfully</div>');
                        $('#wallettotamount').html('Total Wallet Amount: Rs.'+obj.walletamount);
                        $('#amountrecharge').val(0);
                           
                        }else
                        {
                            $('#paymentsuccess').html('<div class="alert alert-danger">Wallet Recharge Failed</div>'); 
                        }
                    }
                })
             
                 
                
              },
             "prefill": {
                  "contact": '9988665544',
                  "email":   'devfeedly21@gmail.com',
              },
              "theme": {
                  "color": "#528FF0"
              }
            };
            var rzp1 = new Razorpay(options);
            rzp1.open();
            e.preventDefault();
    }
    
    function reedempoint(reddem)
    {
         var userid = $('#userid').val();
         $.ajax({
                method: 'post',
                url: "{!!route('updatereddempoint')!!}",
                data: {
                    "_token": "{{ csrf_token() }}",
                   
                    "reddem":reddem,
                    "userid":userid
                },
                success: function (result) {
                var obj = JSON.parse(result);
                if(obj.code == 200)
                {  
                    alert(obj.msg);
                   location.reload();
                }else
                {
                   
                }
                }
         });
    }
</script>
<script type="text/javascript">
function setaddress(addressid)
{
   debugger;

    $.ajaxSetup({
                     headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     }
            });
     $.ajax({
      url: "{{ route('setaddress') }}",
         type:"POST",
         data:{addressid: addressid},
         success: function(result){
            if(result == 1)
            {
                alert("Address set as default Successfully");
                location.reload();
            }
          
         }
      });
}
</script>
</body>
</html>