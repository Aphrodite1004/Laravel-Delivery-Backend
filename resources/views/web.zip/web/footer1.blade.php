<!-- ======= Footer ======= -->
<footer id="footer" >
   <div class="footer-top" style="background-color: #F6F7FC !important;">
      <div class="container">
         <div class="row">
            <div class="col-lg-3 col-md-6 footer-links">
               <h4>Sub Links</h4>
               <ul>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
               </ul>
            </div>
            <div class="col-lg-3 col-md-6 footer-links">
               <h4>For Download</h4>
               <ul>
                  <li><img src="{{ url('frontassets/img/a1.png')}}" style="width: 53%;height: 40px;"></li>
                  <li><img src="{{ url('frontassets/img/g1.png')}}" style="width: 53%;height: 40px;"></li>
                  
               </ul>
            </div>
            <div class="col-lg-3 col-md-6 footer-links">
               <h4>Payment Method</h4>
               <ul>
                  <li><img src="{{ url('frontassets/img/pay1.png')}}" style="width: 63%;position: relative;left: -20px;top: -40px"></li>
                  
               </ul>
            </div>
            <div class="col-lg-3 col-md-6 footer-links">
               <h4>Find Us On</h4>
               <p>Cras fermentum odio eu feugiat lide par naso tierra videa magna derita valies</p>
               <div class="social-links mt-3">
                  
                  <a href="#" class="facebook" style="border-radius: 30px;"><i class="bx bxl-facebook"></i></a>
                  <a href="#" class="instagram" style="border-radius: 30px;"><i class="bx bxl-instagram"></i></a>
                  
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="container py-4">
      <center>
         <div class="copyright" style="margin-bottom: -50px;">
            &copy; Copyright <strong><span>Tecmanic</span></strong>. All Rights Reserved
         </div>
      </center>
   </div>
</footer>
<!-- End Footer -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous"></script>
<script type="text/javascript">
   
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
   
    $("#submit-btn").click(function(e){
  
        e.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
         var name = $("input[name=username]").val();
         var password = $("input[name=password]").val();
         var email = $("input[name=email]").val();
         var mobile = $("input[name=mobile]").val();
        $.ajax({
           type:'POST',
           url:"{{ route('webregister') }}",
           data:{name:name, password:password, email:email,mobile:mobile},
           success:function(data){
                // var obj = JSON.parse(data);
                // alert(obj.success);
               if(data.success)
               {
                   if(data.code == 1)
                   {
                    $('#msgdetails').html('<div id="failedmessage"><div class="alert alert-success">'+data.success+'</div> </div><input type="hidden" name="verify_mobile_number" value="'+mobile+'"><a  onclick="getverifydata()"><b>Verify Mobile<b></a><br><br>');
                        $('#signup').modal('hide');
                        $('#verifyotp').modal('show');
                   }
                  else
                  {
                      $('#msgdetails').html('<div class="alert alert-success">'+data.success+'</div>');
                  }
               }else
               {
                  $('#msgdetails').html('<div class="alert alert-danger">'+data.error+'</div>');
               }
              $(".loader").css('display','none');
           },
           beforeSend : function(){
              
                $(".loader").css('display','block');
            }
        });
  
   });

   $("#login-btn").click(function(e){
        
        e.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
   
         var mobile = $("#mobile").val();
         var password = $("#password").val();
      
        $.ajax({
           type:'POST',
           url:"{{ route('weblogin') }}",
           data:{mobile:mobile, password:password},
           success:function(data){
            // var obj = JSON.parse(data);
            if(data.success)
            {
              $('#login').modal('hide');
              swal({
                title: "SUCCESS",
                text: data.success,
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false
               
               }).then(function(){
                                      window.location.reload();
                                  })

            }else
            {
                $('#loginmsgdetails').html('<div class="alert alert-danger">'+data.error+'</div>');
            }
                 $(".loader").css('display','none');
            },
            beforeSend : function(){
              
                $(".loader").css('display','block');
            }
  
   });
  });
  $("#verifyotpmobile-btn").click(function(e){
        
        e.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
   
         var mobile = $("input[name=verify_mobile_number]").val();
         var verifyotpmobnew = $("input[name=verifyotpmobnew]").val();
         debugger;
      
        $.ajax({
          type:'POST',
          url:"{{ route('webotpverify') }}",
          data:{mobile:mobile, verifyotpmobnew:verifyotpmobnew},
          success:function(data){
            //   var obj = JSON.parse(data);
            if(data.success)
            { 
               debugger;
            $('#verifyotp').modal('hide');
              swal({
                title: "SUCCESS",
                text: data.success,
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false
               
              }).then(function(){
                                      window.location.reload();
                                  })

            }else
            {
                $('#failedmessage').html('<div class="alert alert-danger">'+data.error+'</div>');
            }
                 $(".loader").css('display','none');
            },
            beforeSend : function(){
              
                $(".loader").css('display','block');
            }
  
  });
  });

  $("#forgotpassword").click(function(e){
      debugger;
        e.preventDefault();
      var mobile = $('#forgotmobile').val();
       $.ajaxSetup({
                     headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     }
            });
            $.ajax({
               url: "{{ route('webforgotpassword') }}",
               type:"POST",
               data:{mobile: mobile},
               success: function(result){
                   if(result == 1)
                   {
                       $('#forgotphone').val(mobile);
                       $('#forgot_pass').modal('hide');
                       $('#forgot_pass_otp').modal('show');
                   }
               }
            });
      
  });
  function finalotpverify()
  {
   debugger;
      var mobile = $('#forgotphone').val();
      var otp = $('#otp').val();
       $.ajaxSetup({
                     headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     }
            });
            $.ajax({
               url: "{{ route('otpverifyforgotpassword') }}",
               type:"POST",
               data:{mobile: mobile,otp:otp},
               success: function(result){
                  debugger;
                  if(result == 1)
                  {
                      $('#updatephone').val(mobile);
                      $('#forgot_pass_otp').modal('hide');
                      $('#updatepassword').modal('show');
                  }else
                  {
                       $('#msgdiv').html('<div class="alert alert-danger col-md-12">Otp Not Match</div>')
                  }
               }
            });
  }
  function updatepassword()
  {
   debugger;
      var mobile  =  $('#updatephone').val();
      var newpassword = $('#newpassword').val();
      var confirmpassword =  $('#confirmpassword').val();
      if(newpassword != confirmpassword)
      {
          $('#confirmmsg').html("New password not match with Confirm password ");
          $('#confirmmsg').css('color','red');
      }
      else
      {
         debugger;

      $.ajaxSetup({
                     headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     }
            });
            $.ajax({
               url: "{{ route('webupdatepassword') }}",
               type:"POST",
               data:{newpassword: newpassword,confirmpassword:confirmpassword,mobile:mobile},
               success: function(result){
                  debugger;
                  if(result == 1)
                  {
                      $('#updatepassword').modal('hide');
                     swal({
                        title: "Success",
                        text: "Password Update Successfully",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Yes, delete it!",
                        closeOnConfirm: false
                       
                       }).then(function(){
                                              window.location.reload();
                                          })
                  }
               }
            });
      }
      
  }
  function getverifydata()
  {
     
  }
  </script>